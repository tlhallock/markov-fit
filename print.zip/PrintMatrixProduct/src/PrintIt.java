
public class PrintIt {

	static Expression getMatrixExponential(Matrix left, Matrix matrix, Matrix right, int order) {
		Sum sum = new Sum();

		Matrix currentPower = Matrix.createIdentity(matrix.m);
		double denominator = 1.0;

		for (int i = 0; i <= order; i++)
		{
			if (i > 0)
				denominator /= i;
			
			sum.add(new Product(new Value(denominator),
							Expression.simplifyExpression(
									Matrix.multiply(
											Matrix.multiply(left, currentPower),
											right))));

			currentPower = Matrix.multiply(matrix, currentPower);
		}

		return Expression.simplifyExpression(sum);
	}
	
	
	
	
	
	
	
	
	
	

	public static void main(String[] args) {
		int n = 3;
		int order = 5;

		Matrix left = Matrix.createZeros(1, n);
		left.elems[0][n - 1] = new One();
		Matrix right = Matrix.createOnes(n, 1);
		Matrix middle = Matrix.createMatrix("q", n, n);

		Expression expr = getMatrixExponential(left, middle, right, 5);

		
		System.out.println("double mat_exp(const double *const q) {");
		System.out.print("\treturn ");
		System.out.print(expr.toC(new StringBuilder()).toString());
		System.out.print(";\n");
		System.out.println("}");
		
		
		
		

		System.out.println("void *mat_exp_grad(const double *const q, double *output) {");
		for (int i=0;i<n*n;i++)
		{
			System.out.print("\toutput[" + i + "] = -(");
			System.out.print(Expression.simplifyExpression(expr.differentiate(new Variable("q[" + i + "]"))).toC(new StringBuilder()));
			System.out.println(");");
		}
		System.out.println("}");
	}

}
